export const bike={
    bajaj:require('./bajaj/avenger-street-160.webp'),
    enfield:require('./enfield/bullet.webp'),
    hero:require('./hero/destini.webp'),
    honda:require('./honda/activa-6g.webp'),
    ktm:require('./ktm/250.webp'),
    suzuki:require('./suzuki/access.webp'),
    tvs:require('./tvs/apache-160.webp'),

}